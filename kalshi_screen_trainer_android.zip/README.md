# Kalshi Screen AI Trainer & Chart Interpreter (Pixel 9 Pro XL)

This native Android application runs directly on your Google Pixel 9 Pro XL. It uses Android's **MediaProjection API** to capture what the Kalshi app is displaying in real-time, interprets the live BTC chart and contract prices using a multimodal vision model, and overlays an interactive **floating HUD badge** directly over Kalshi.

---

## Key Features

1. **Direct Screen Interpretation**:
   - Takes a direct snapshot of your active display when you tap the floating overlay.
   - Reads the exact contract title, target strike price, expiration timer, and live Yes/No order-book pricing visible inside Kalshi.

2. **AI Chart Trainer & Quantitative Analysis**:
   - Analyzes BTC spot position relative to the strike line.
   - Computes distance to strike ($ and %) and calculates the required price velocity ($/min) needed for a contract to settle in-the-money.
   - Evaluates time decay (theta) risk and explains scenarios objectively without making reckless directional gambling bets.

3. **Floating Interactive HUD (System Overlay)**:
   - Sits as a compact, draggable floating bubble on your screen while you use Kalshi.
   - Expands on tap to show detailed chart insights, probability drift, and educational takeaways.
   - Built-in **Text-to-Speech (TTS)**: Tap the speaker icon to hear the trainer speak the chart summary aloud.

---

## How to Build and Run on Your Pixel 9 Pro XL

### Step 1: Open in Android Studio
1. Unzip `kalshi_screen_trainer_android.zip`.
2. Open the unzipped folder in **Android Studio (Ladybug or newer)**.
3. Allow Gradle to sync the dependencies.

### Step 2: Enable Developer Options on Your Pixel 9 Pro XL
1. Go to **Settings > About phone** on your Pixel 9 Pro XL.
2. Tap **Build number** 7 times until Developer Mode is unlocked.
3. Go to **Settings > System > Developer options** and turn on **USB debugging** (or Wireless Debugging).

### Step 3: Install the App
1. Connect your phone to your computer.
2. In Android Studio, select your **Pixel 9 Pro XL** in the target device selector.
3. Click the green **Run (▶)** button to install and launch the app.

### Step 4: Grant Permissions & Launch
1. Open **Kalshi Screen Trainer** on your phone.
2. Enter your **Gemini Vision API Key** (obtain free from [Google AI Studio](https://aistudio.google.com/)).
3. Tap **Launch Floating Trainer HUD**.
4. Grant the **Display over other apps** permission.
5. Tap **Start now** when prompted for screen recording permission.
6. Open your **Kalshi app** and navigate to any BTC market. Tap the floating AI badge to inspect and interpret the live chart!
