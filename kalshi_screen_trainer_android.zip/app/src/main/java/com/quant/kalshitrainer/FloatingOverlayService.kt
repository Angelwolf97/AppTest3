package com.quant.kalshitrainer

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class FloatingOverlayService : Service(), TextToSpeech.OnInitListener {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var floatingBubble: View
    private lateinit var hudCard: View

    private lateinit var tvMarketTitle: TextView
    private lateinit var tvStrikePrice: TextView
    private lateinit var tvTimeRemaining: TextView
    private lateinit var tvChartAnalysis: TextView
    private lateinit var tvProbabilityEdge: TextView
    private lateinit var tvEducationalInsight: TextView
    private lateinit var btnAnalyzeNow: Button
    private lateinit var btnMinimize: ImageButton
    private lateinit var btnSpeak: ImageButton
    private lateinit var progressBar: ProgressBar

    private var tts: TextToSpeech? = null
    private var lastTrainerSummary: String = ""
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        initOverlayViews()
    }

    @SuppressLint("InflateParams")
    private fun initOverlayViews() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.layout_floating_hud, null)

        floatingBubble = overlayView.findViewById(R.id.floatingBubble)
        hudCard = overlayView.findViewById(R.id.hudCard)

        tvMarketTitle = overlayView.findViewById(R.id.tvMarketTitle)
        tvStrikePrice = overlayView.findViewById(R.id.tvStrikePrice)
        tvTimeRemaining = overlayView.findViewById(R.id.tvTimeRemaining)
        tvChartAnalysis = overlayView.findViewById(R.id.tvChartAnalysis)
        tvProbabilityEdge = overlayView.findViewById(R.id.tvProbabilityEdge)
        tvEducationalInsight = overlayView.findViewById(R.id.tvEducationalInsight)
        btnAnalyzeNow = overlayView.findViewById(R.id.btnAnalyzeNow)
        btnMinimize = overlayView.findViewById(R.id.btnMinimize)
        btnSpeak = overlayView.findViewById(R.id.btnSpeak)
        progressBar = overlayView.findViewById(R.id.progressBar)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 200
        }

        // Draggable floating touch handler
        floatingBubble.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(overlayView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffX = Math.abs(event.rawX - initialTouchX)
                        val diffY = Math.abs(event.rawY - initialTouchY)
                        if (diffX < 10 && diffY < 10) {
                            toggleHudCard()
                        }
                        return true
                    }
                }
                return false
            }
        })

        btnMinimize.setOnClickListener {
            hudCard.visibility = View.GONE
            floatingBubble.visibility = View.VISIBLE
        }

        btnAnalyzeNow.setOnClickListener {
            performScreenInterpretation()
        }

        btnSpeak.setOnClickListener {
            if (lastTrainerSummary.isNotEmpty()) {
                tts?.speak(lastTrainerSummary, TextToSpeech.QUEUE_FLUSH, null, "TrainerSpeech")
            }
        }

        windowManager.addView(overlayView, params)
    }

    private fun toggleHudCard() {
        if (hudCard.visibility == View.VISIBLE) {
            hudCard.visibility = View.GONE
        } else {
            hudCard.visibility = View.VISIBLE
            performScreenInterpretation()
        }
    }

    /**
     * Captures the screen of Kalshi and sends it to the Vision AI Trainer
     */
    private fun performScreenInterpretation() {
        val captureService = ScreenCaptureService.instance
        if (captureService == null) {
            Toast.makeText(this, "Screen capture service not initialized", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        btnAnalyzeNow.isEnabled = false
        tvEducationalInsight.text = "Reading Kalshi screen and analyzing BTC chart..."

        // Temporary hide overlay view so it doesn't occlude the Kalshi chart
        overlayView.visibility = View.INVISIBLE

        serviceScope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(200) // allow window render
            captureService.captureCurrentScreenBitmap { bitmap ->
                serviceScope.launch(Dispatchers.Main) {
                    overlayView.visibility = View.VISIBLE
                    if (bitmap == null) {
                        progressBar.visibility = View.GONE
                        btnAnalyzeNow.isEnabled = true
                        tvEducationalInsight.text = "Could not capture frame. Ensure Kalshi is open on screen."
                        return@launch
                    }

                    // Retrieve API Key
                    val prefs = getSharedPreferences("kalshi_trainer_prefs", Context.MODE_PRIVATE)
                    val apiKey = prefs.getString("gemini_api_key", "") ?: ""

                    // Send frame to Vision Model
                    KalshiVisionTrainer.analyzeKalshiScreen(bitmap, apiKey) { result ->
                        progressBar.visibility = View.GONE
                        btnAnalyzeNow.isEnabled = true
                        if (result != null) {
                            tvMarketTitle.text = result.marketTitle
                            tvStrikePrice.text = "Strike: ${result.strikePrice}"
                            tvTimeRemaining.text = "Expiry: ${result.timeRemaining}"
                            tvChartAnalysis.text = result.chartAnalysis
                            tvProbabilityEdge.text = result.probabilityCalculation
                            tvEducationalInsight.text = result.educationalTakeaway
                            lastTrainerSummary = "${result.marketTitle}. ${result.chartAnalysis}. ${result.educationalTakeaway}"
                        } else {
                            tvEducationalInsight.text = "Analysis failed. Please verify API key and network connection."
                        }
                    }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }
}