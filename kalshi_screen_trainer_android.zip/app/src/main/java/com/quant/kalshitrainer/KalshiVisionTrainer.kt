package com.quant.kalshitrainer

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class TrainerInterpretationResult(
    val marketTitle: String,
    val strikePrice: String,
    val timeRemaining: String,
    val chartAnalysis: String,
    val probabilityCalculation: String,
    val educationalTakeaway: String
)

object KalshiVisionTrainer {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /**
     * Sends the captured Kalshi screen bitmap to Gemini 1.5 Flash Vision endpoint
     */
    suspend fun analyzeKalshiScreen(
        bitmap: Bitmap,
        apiKey: String,
        callback: (TrainerInterpretationResult?) -> Unit
    ) {
        withContext(Dispatchers.IO) {
            try {
                // Compress bitmap to JPEG Base64
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
                val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

                val promptText = """
You are an expert quantitative trading educator and chart trainer assistant inspecting the user's mobile screen while they view a Bitcoin (BTC) contract inside the Kalshi prediction market app.

Carefully inspect the image of the Kalshi screen and extract the exact details visible:
1. Identify the specific contract name, target strike price, and countdown to expiration visible on screen.
2. Read the chart trend: Is BTC spot trading above or below the strike line? What are the recent candlestick/line patterns and momentum direction?
3. Calculate the distance in dollars and percentage between the current spot price and the strike threshold.
4. Read the Kalshi YES / NO market prices (implied probability in cents).
5. Provide objective, educational trainer guidance:
   - What velocity (${'$'}/min or ${'$'}/hour) would BTC need to sustain to settle YES before expiry?
   - Explain how time decay (theta) affects the contract value as the deadline approaches.
   - Outline the risk profile (binary payoff: ${'$'}1.00 vs ${'$'}0.00).
   - NEVER make guaranteed predictions or encourage irresponsible gambling. Frame all analysis objectively as a training interpreter.

Return your response strictly in the following JSON format:
{
  "marketTitle": "Brief contract title (e.g. BTC > $68,250 at 2:00 PM)",
  "strikePrice": "Strike price with dollar sign (e.g. $68,250)",
  "timeRemaining": "Time left until settlement (e.g. 18m 42s)",
  "chartAnalysis": "2-3 sentences describing price action, support/resistance, and spot distance to strike",
  "probabilityCalculation": "Comparison between Kalshi implied odds (e.g. Yes 48¢ = 48%) and price drift distance",
  "educationalTakeaway": "Key educational guidance on the risk-reward ratio, time decay velocity, and scenario analysis"
}
""".trimIndent()

                // Construct Gemini API Payload
                val jsonBody = JSONObject().apply {
                    val contentsArray = JSONArray()
                    val contentObject = JSONObject()
                    val partsArray = JSONArray()

                    // Text prompt part
                    partsArray.put(JSONObject().apply { put("text", promptText) })

                    // Image part
                    val inlineData = JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", base64Image)
                    }
                    partsArray.put(JSONObject().apply { put("inline_data", inlineData) })

                    contentObject.put("parts", partsArray)
                    contentsArray.put(contentObject)
                    put("contents", contentsArray)

                    // Generation config for JSON output
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.2)
                        put("response_mime_type", "application/json")
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && !responseBody.isNullOrEmpty()) {
                    val jsonResponse = JSONObject(responseBody)
                    val candidates = jsonResponse.getJSONArray("candidates")
                    if (candidates.length() > 0) {
                        val text = candidates.getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                            .getJSONObject(0)
                            .getString("text")

                        val parsedResult = JSONObject(text)
                        val result = TrainerInterpretationResult(
                            marketTitle = parsedResult.optString("marketTitle", "Kalshi BTC Contract"),
                            strikePrice = parsedResult.optString("strikePrice", "N/A"),
                            timeRemaining = parsedResult.optString("timeRemaining", "Live"),
                            chartAnalysis = parsedResult.optString("chartAnalysis", "Chart analyzed."),
                            probabilityCalculation = parsedResult.optString("probabilityCalculation", "N/A"),
                            educationalTakeaway = parsedResult.optString("educationalTakeaway", "Observe time decay closely.")
                        )
                        callback(result)
                        return@withContext
                    }
                }
                callback(null)
            } catch (e: Exception) {
                e.printStackTrace()
                callback(null)
            }
        }
    }
}