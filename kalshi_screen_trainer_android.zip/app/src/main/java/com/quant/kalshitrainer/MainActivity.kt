package com.quant.kalshitrainer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val REQUEST_OVERLAY_CODE = 1001
    private val REQUEST_MEDIA_PROJECTION_CODE = 1002

    private lateinit var mediaProjectionManager: MediaProjectionManager
    private lateinit var tvStatus: TextView
    private lateinit var etApiKey: EditText
    private lateinit var btnStartOverlay: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        tvStatus = findViewById(R.id.tvStatus)
        etApiKey = findViewById(R.id.etApiKey)
        btnStartOverlay = findViewById(R.id.btnStartOverlay)

        // Load saved API key
        val prefs = getSharedPreferences("kalshi_trainer_prefs", Context.MODE_PRIVATE)
        val savedKey = prefs.getString("gemini_api_key", "")
        if (!savedKey.isNullOrEmpty()) {
            etApiKey.setText(savedKey)
        }

        btnStartOverlay.setOnClickListener {
            val key = etApiKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Please enter your Gemini API key for vision chart analysis", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("gemini_api_key", key).apply()

            checkPermissionsAndStart()
        }
    }

    private fun checkPermissionsAndStart() {
        // Step 1: Check Overlay permission
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY_CODE)
            return
        }

        // Step 2: Request MediaProjection capture token
        startActivityForResult(
            mediaProjectionManager.createScreenCaptureIntent(),
            REQUEST_MEDIA_PROJECTION_CODE
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_OVERLAY_CODE) {
            if (Settings.canDrawOverlays(this)) {
                checkPermissionsAndStart()
            } else {
                Toast.makeText(this, "Overlay permission is required to display the trainer over Kalshi", Toast.LENGTH_LONG).show()
            }
        } else if (requestCode == REQUEST_MEDIA_PROJECTION_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                // Start Screen Capture Service
                val captureServiceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("RESULT_CODE", resultCode)
                    putExtra("DATA_INTENT", data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(captureServiceIntent)
                } else {
                    startService(captureServiceIntent)
                }

                // Start Floating HUD Overlay Service
                val overlayIntent = Intent(this, FloatingOverlayService::class.java)
                startService(overlayIntent)

                Toast.makeText(this, "Kalshi Screen Trainer started! Open Kalshi app to begin.", Toast.LENGTH_LONG).show()
                finish() // Minimize to background
            } else {
                Toast.makeText(this, "Screen capture permission was declined", Toast.LENGTH_SHORT).show()
            }
        }
    }
}